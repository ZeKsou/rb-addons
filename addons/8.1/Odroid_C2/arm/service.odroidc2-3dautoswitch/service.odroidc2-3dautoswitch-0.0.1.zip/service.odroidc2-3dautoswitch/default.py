﻿import os, xbmc, json
 
class xbmcPlayer(xbmc.Player):
  def __init__(self, *args):
    pass
 
  def onPlayBackStarted(self):
    if self.isPlayingVideo():
      stereomode = ''
      try:
        info = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetItem", "params": { "properties": ["streamdetails"], "playerid": 1 }, "id": "VideoGetItem"}'))['result']['item']
      except RuntimeError:
        info = {}
      else:
        if 'streamdetails' in info.keys():
          sm = info.pop('streamdetails', {})
          try:
            stereomode = sm['video'][0]['stereomode']
          except (KeyError, IndexError):
            stereomode = 'non'
          else:
            if stereomode == '':
              stereomode = 'non'
 
      if stereomode == 'left_right':
        os.system("sleep 2 && echo '3dlr' > /sys/class/amhdmitx/amhdmitx0/config")
 
      if stereomode == 'top_bottom':
        os.system("sleep 2 && echo '3dtb' > /sys/class/amhdmitx/amhdmitx0/config")
 
if __name__ == '__main__':
  player = xbmcPlayer() 
  monitor = xbmc.Monitor()
 
  while not monitor.abortRequested():
    if monitor.waitForAbort(1):
      break