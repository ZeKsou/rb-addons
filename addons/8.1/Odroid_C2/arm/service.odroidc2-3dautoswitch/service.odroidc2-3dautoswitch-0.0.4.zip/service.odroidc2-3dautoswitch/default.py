﻿import os, xbmc, xbmcaddon, time, json

class xbmcPlayer(xbmc.Player):

  def __init__(self, *args):
    xbmcPlayer.stereomodeactive = 'false'

  def onPlayBackStarted(self):
    if self.isPlayingVideo():
      usersettings = xbmcaddon.Addon()
      waitfor3d = float(usersettings.getSetting('waitfor3d'))
      stereomode = ''
      try:
        stereomode = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "XBMC.GetInfoLabels", "params": { "labels": ["VideoPlayer.StereoscopicMode"] }, "id": "GetInfoLabels"}'))['result']['VideoPlayer.StereoscopicMode']
      except:
        stereomode = ''

      if stereomode == 'left_right':
        time.sleep(waitfor3d)
        os.system("echo '3dlr' > /sys/class/amhdmitx/amhdmitx0/config")
        xbmcPlayer.stereomodeactive = 'true'

      if stereomode == 'top_bottom':
        time.sleep(waitfor3d)
        os.system("echo '3dtb' > /sys/class/amhdmitx/amhdmitx0/config")
        xbmcPlayer.stereomodeactive = 'true'

  def onPlayBackStopped(self):
    usersettings = xbmcaddon.Addon()
    use3doff = bool(usersettings.getSetting('use3doff')) 
    if (xbmcPlayer.stereomodeactive == 'true' and use3doff):
      os.system("echo '3doff' > /sys/class/amhdmitx/amhdmitx0/config")
    xbmcPlayer.stereomodeactive = 'false'

  def onPlayBackEnded(self):
    usersettings = xbmcaddon.Addon()
    use3doff = bool(usersettings.getSetting('use3doff')) 
    if (xbmcPlayer.stereomodeactive == 'true' and use3doff):
      os.system("echo '3doff' > /sys/class/amhdmitx/amhdmitx0/config")
    xbmcPlayer.stereomodeactive = 'false'

if __name__ == '__main__':
  player = xbmcPlayer() 
  monitor = xbmc.Monitor()
  while not monitor.abortRequested():
    if monitor.waitForAbort(1):
      break